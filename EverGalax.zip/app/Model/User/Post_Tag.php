<?php

namespace App\Model\User;

use Illuminate\Database\Eloquent\Model;

class post_tag extends Model
{
    //
}
