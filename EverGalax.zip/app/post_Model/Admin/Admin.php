<?php

namespace App\post_Model\Admin;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    //
}
