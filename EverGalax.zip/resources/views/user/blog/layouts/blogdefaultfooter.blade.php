	
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="{{ asset('js/app.js') }}"></script>
		<script src="{{ asset('js/script.js') }}"></script>
	</body>
</html>