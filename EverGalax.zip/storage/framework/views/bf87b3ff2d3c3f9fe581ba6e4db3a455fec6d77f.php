<table class="table table-hover w-auto table-responsive table-bordered">
    <!--Table head-->
    <thead class="bg-color-table">
        <tr>
            <th>#</th>
            <th>Category Name</th>
            <th>Category Description</th>
            <th>Category Slug</th>
            <th>Parent Category</th>
        </tr>
    </thead>
    <!--Table head-->

    <!--Table body-->

    <tbody>
        <tr>
            <th scope="row">1</th>
                <td>
                    Java Programing
                    <p>edit</p>
                    <p>Delete</p>
                </td>

                <td>Lorem Ispeium Lorem Ispeium Lorem Ispeium Lorem Ispeium Lorem Ispeium Lorem Ispeium</td>
                <td>/java-programing</td>
                <td>N/A</td>
        </tr>
    </tbody>
</table>