<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="icon" href="<?php echo e(URL::asset('/images/EverGalax Logo.png')); ?>" type="image/x-icon">


		<!-- CSRF Token -->
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css">

		<!-- Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

		<!-- Styles -->
         <?php if(Route::has('login')): ?>
            
            <?php if(auth()->guard()->check()): ?>
                 <link type="text/css" href="<?php echo e(asset('css/authmain.css')); ?>" rel="stylesheet">
            <?php else: ?>
                
                <link type="text/css" href="<?php echo e(asset('css/guest.css')); ?>" rel="stylesheet">

            <?php endif; ?>
        <?php endif; ?>
        <link type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>" rel="stylesheet" media="screen  and (min-width: 400px)" />