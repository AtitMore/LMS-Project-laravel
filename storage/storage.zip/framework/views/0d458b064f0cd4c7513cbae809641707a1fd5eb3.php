 <?php echo $__env->make('layouts.defaultheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if(auth()->guard()->guest()): ?>

       <title>Welcome To EverGalax - Login</title>
    <?php else: ?>

    <?php endif; ?>
    
</head>
<body style="background-color: #f2f2f2;">


    <div id="container-fluid">

        <!-- Header-->
        <div id="header">   
            <div class ="container">
                                             
                <!--Logo-->
                <div class="col-sm">
                    <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(URL::asset('images/Logo Name.png')); ?>" width="200px" height="33px" alt="EverGalax" id="eg-logo" style="position: fixed;"></a>
                </div>

                
                <!-- Right Menu's-->
                <div class="col-sm">
                                    
                    <ul id="right-side-header">

                        <li class="list-right-side">
                            <a href="#section-1" id="header-cnt"><p class="list-font">FAQ</span></a>
                        </li>

                        <li class="list-right-side">
                            <a href="<?php echo e(route('register')); ?>" id="header-signup"><p class="list-font">Signup<i class="line"></i></p></a>
                        </li>

                        <li class="list-right-side">
                            <a href="<?php echo e(route('login')); ?>" id="header-login"><p class="list-font">Login<i class="line"></i></p></a>
                        </li>
                    </ul>
                </div>
            </div> 
        </div> 
                        
                    
        <!-- Main-->
        <!-- Section 1-->

        <?php echo $__env->yieldContent('content'); ?>
    

    <!-- Scripts -->

</body>
</html>
