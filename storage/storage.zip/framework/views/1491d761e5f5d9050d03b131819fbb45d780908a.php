<?php echo $__env->make('user.blog.layouts.blogdefaultheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<a href = "<?php echo e(route('post',$post->slug)); ?>">
	<h2><?php echo e($post->title); ?></h2>
