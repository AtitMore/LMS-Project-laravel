 <?php echo $__env->make('admin/layouts/admindefaultheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

   <!-- Content Header (Page header) -->
   <div class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6">
               <h1 class="m-0 text-dark">Role</h1>
            </div><!-- /.col -->

            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Role List</a></li>
                  <li class="breadcrumb-item active">Role</li>
               </ol>
            </div><!-- /.col -->
         </div><!-- /.row -->
      </div><!-- /.container-fluid -->
   </div>
   <!-- /.content-header -->

  <div class="card">
      <div class="card-header">
         <div class="col-sm-6 float-left">
            <h3 class="card-title">Role List</h3>
         </div>
         <div class="float-right">
            <a class='col-lg-offset-5 btn btn-success' href="<?php echo e(route('role.create')); ?>">Add New</a>
         </div>
      </div>

            
      <!-- /.card-header -->
         <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
               <thead>
                  <tr>
                     <th>Sr. No</th>
                     <th>Role Name</th>
                  </tr>
               </thead>

               <tbody>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e($loop->index + 1); ?></td>
                     <td>
                        <div class="col-sm">
                           <?php echo e($role->name); ?>

                        </div>
                        <div class="d-inline-block col-sm">
                           <div class="col-sm-5 float-left">
                              <a href="<?php echo e(route('role.edit', $role->id)); ?>">
                                 <p><i class="fa fa-pencil-square">
                                 edit</p></i>
                              </a>
                           </div>
                           <div class="col-sm-5 float-left">
                              <form id="delete-form-<?php echo e($role->id); ?>" action="<?php echo e(route('role.destroy', $role->id)); ?>" style="display: none;" method="post">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('DELETE'); ?>
                              </form>
                              <a href="<?php echo e(route('role.index')); ?>" onclick="
                              if(confirm('Are You Sure, You Want To Delete This?')){
                                 event.preventDefault();
                                 document.getElementById('delete-form-<?php echo e($role->id); ?>').submit();
                              }
                              else{
                                 event.preventDefault();
                              }">
                                 <p><i class="fa fa-trash-o">Delete</p></i>
                              </a>
                           </div>
                        </div>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
               <tfoot>
                  <tr>
                     <th>Sr. No</th>
                     <th>Role Name</th>
                  </tr>
               </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>

</div>
 <?php echo $__env->make('admin/layouts/admindefaultfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  