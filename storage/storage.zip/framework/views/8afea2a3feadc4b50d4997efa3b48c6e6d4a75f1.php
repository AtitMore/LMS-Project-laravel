<?php echo $__env->make('admin/layouts/admindefaultheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-wrapper">

   <!-- Content Header (Page header) -->
   	<section class="content-header">
      	<div class="container-fluid">
         	<div class="row mb-2">
            	<div class="col-sm-6">
               		<h1 class="m-0 text-dark">Category</h1>
            	</div><!-- /.col -->

            	<div class="col-sm-6">
               		<ol class="breadcrumb float-sm-right">
                  		<li class="breadcrumb-item"><a href="#">Create New Category</a></li>
                 		 <li class="breadcrumb-item active">Category</li>
               		</ol>
            	</div><!-- /.col -->
         	</div><!-- /.row -->
      	</div><!-- /.container-fluid -->
   	</section>
   <!-- /.content-header -->

   <!-- general form elements -->
   <section class="content">
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-9">
               <div class="card card-primary card-info">
                  <div class="card-header">
                     <h3 class="card-title">Create Category</h3>
                  </div>

                  <!-- /.card-header -->
                  <!-- form start -->
                  <form role="form" action="<?php echo e(route('category.store')); ?>" method="post">
                     <?php echo csrf_field(); ?>
                     <div class="card-body">
                         <div class="form-group">
                         	<label for="categoryName">Category Name</label>
                             <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="name" name="name" placeholder="Enter Category Name">
                              <?php if($errors->has('name')): ?>
                                 <span class="invalid-feedback">
                                    <strong>Category <?php echo e($errors->first('name')); ?></strong>
                                 </span>
                              <?php endif; ?>
                         </div>
                           
                         <div class="form-group">
                         	<label for="categorySlug">Slug</label>
                             <input type="text" class="form-control<?php echo e($errors->has('slug') ? ' is-invalid' : ''); ?>" id="slug" name="slug" placeholder="Enter Slug">
                              <?php if($errors->has('slug')): ?>
                                 <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('slug')); ?></strong>
                                 </span>
                              <?php endif; ?>
                         </div>

                         <!-- textarea -->
                         <div class="form-group">
                             <label>Textarea</label>
                             <textarea class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" rows="3" id="description" name="description" placeholder="Enter Category Description"></textarea>
                              <?php if($errors->has('description')): ?>
                                 <span class="invalid-feedback">
                                    <strong>Category <?php echo e($errors->first('description')); ?></strong>
                                 </span>
                              <?php endif; ?>
                         </div>

                         <!-- select --
                        <div class="form-group">
                         	<label>Parent Category</label>
                              <select class="form-control">
                             	   <option>None</option>
                             	   <option>Computer Programming</option>
                               	<option>Web designing</option>
                              </select>
                              <?php if($errors->has('slug')): ?>
                                 <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('slug')); ?></strong>
                                 </span>
                              <?php endif; ?>
                         </div>-->
                     </div>
                     <!-- /.card-body -->

                     <div class="card-footer">
                         <input type="submit" class="btn btn-primary" value="submit">
                     </div>
                 </form>
               </div>
            </div>
         </div>
      </div>
   </section>         
    <!-- /.card -->
</div>


<?php echo $__env->make('admin/layouts/admindefaultfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  