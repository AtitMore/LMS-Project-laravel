 <?php echo $__env->make('layouts.defaultheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<title>Category - <?php echo e(Auth::user()->getFirstnameOrUsername()); ?>'s</title>
		
	</head>
	<body>
		<div id="containers">
			
			<!-- header -->
			<div class="header">
                <div class="header-container clearfix wrapper"> 
                    <a class="navbar-brands" href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(asset('images/EverGalax Logo.png')); ?>" width="38px" height="38px" alt="EverGalax" id="eg-logo" style="position: fixed;">
                    </a>

                    <div class="header-search">
                        <div class="search-box">
                            <form method="get" role="search" action="">
                                <input type="search" name="query" class="search-control" placeholder="Search people, live events, videos, learning"></input>
                        
                        </div>
                            <button type="submit" class="search-btn">Search</button>
                        </form>  
                    </div>
                        
                    <ul id="header-nav">
                        <li class="header-nav-item dropdown res-nav-item">
                            <a href="#" onclick="showdropdown()" class="dropdown-btn">
                                <i class="fa fa-chevron-down fa-head-fcolor">
                                    <ul id="menu" onclick="hidedropdown()" class="dropdown-content">
                                        <li>Create Page</li>
                                        <li>Create Group</li>
                                        <li>New Groups</li><hr class="dropdown-hr">
                                        <li>Create Ads</li>
                                        <li>Advertising on EverGalax</li><hr class="dropdown-hr">
                                        <li>Activity Log</li>
                                        <li>News Feed Preferences</li>
                                        <li><a href="">Settings</a>
                                        </li><hr class="dropdown-hr">
                                        <li>Help</li>
                                        <li>Support Inbox</li>
                                        <li>Report a Problem</li><hr class="dropdown-hr">
                                        <form>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                        <a href="<?php echo e(route('logout')); ?>">
                                            <li>Logout</li>
                                        </a>
                                        </form>
                                    </ul>
                                </i>
                            </a>
                        </li>

                        <li class="header-nav-item res-nav-item">
                            <i class="fa fa-cog fa-head-fcolor"></i>
                        </li>
                    
                        <li class="header-nav-item">
                            <i class="fa fa-graduation-cap fa-head-fcolor"></i>
                        </li>
        
                        <li class="header-nav-item">
                            <i class="fa fa-bell-o fa-head-fcolor"></i>
                        </li>
                            
                        <li class="header-nav-item">
                            <i class="fa fa-envelope-o fa-head-fcolor"></i>
                        </li>
                    
                        <li class="header-nav-item">
                            <i class="fa fa-user-plus fa-head-fcolor"></i>
                        </li>

                        <li class="header-nav-item">
                            <a href="<?php echo e(route ('home')); ?>">
                                <i class="fa fa-home fa-head-fcolor" style="margin-left: 20px;"></i>
                            </a>
                        </li>
        
                        <li class="header-nav-item">
                            <a href="<?php echo e(Auth::user()->slug); ?>" class="fa-head-fcolor">Welcome <?php echo e(Auth::user()->getFirstnameOrUsername()); ?></a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Body -->

            <div id="body-start">
                <div class="body-container-prof clearfix wrapper">
                    <div class="cate_title_section">
                        <div class="cate_title_adj">
                            <h2>Categories Setting</h2>
                        </div>
                    </div>

                    <div class="left-sect-cate">
                        <div class="left-sect-adjs">
                            <h3>Add Categories</h3>
                            <form method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                     <div class="col-md-12">
                                        <input id="category_name" type="text" class="form-control<?php echo e($errors->has('category_name') ? ' is-invalid' : ''); ?> inputep" name="category_name" placeholder="Add New Category" required autofocus>

                                        <?php if($errors->has('category_name')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('category_name')); ?></strong>
                                        </span>
                                        <?php endif; ?>

                                     </div>
                                </div>

                                <div class="form-group row">
                                     <div class="col-md-12">
                                        <textarea rows="10px" cols="5px" placeholder="Add Category Description" class="form-control<?php echo e($errors->has('category_description') ? ' is-invalid' : ''); ?>" id="category_description" name="category_description"  required autofocus></textarea>

                                        <?php if($errors->has('category_description')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('category_description')); ?></strong>
                                        </span>
                                        <?php endif; ?>

                                     </div>
                                </div>

                                <div class="form-group row">
                                     <div class="col-md-12">
                                        <input id="category_slug" type="text" class="form-control<?php echo e($errors->has('category_slug') ? ' is-invalid' : ''); ?> inputep" name="category_slug" placeholder="Add Category Slug" required autofocus>

                                        <?php if($errors->has('category_slug')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('category_slug')); ?></strong>
                                        </span>
                                        <?php endif; ?>

                                     </div>
                                </div>
                                <input type="submit" name="">
                            </form>
                        </div>
                    </div>

                    <div class="right-sect-cate">
                        <div class="left-sect-adjs">
                            <div class="cate-table">
                                 <?php echo $__env->make('category.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>