
		        <footer class="main-footer">
    			<strong>Copyright &copy; <?php echo e(Carbon\carbon::now()->year); ?> <a href="http//www.evergalax.com">EverGalax</a>.</strong>All rights reserved.
    
    			
  </footer>
		        </div>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script src="<?php echo e(asset('js/app.js')); ?>"></script>
		<script src="<?php echo e(asset('js/admin/script.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(asset('js/select2.full.min.js')); ?>"></script>
      <script src="//cdn.ckeditor.com/4.10.0/full/ckeditor.js"></script>
		<script>
         $(function () {
            // Replace the <textarea id="editor1"> with a CKEditor
            // instance, using default configuration.
            CKEDITOR.replace('editor');
               //bootstrap WYSIHTML5 - text editor
               $(".textarea").wysihtml5();
         });
      </script>

      <script>

      $(document).ready(function() {
          $(".select2").select2();
      });
    </script>

	</body>
</html>