 <?php echo $__env->make('admin/layouts/admindefaultheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

   <!-- Content Header (Page header) -->
   <div class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6">
               <h1 class="m-0 text-dark">Post</h1>
            </div><!-- /.col -->

            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Post List</a></li>
                  <li class="breadcrumb-item active">Post</li>
               </ol>
            </div><!-- /.col -->
         </div><!-- /.row -->
      </div><!-- /.container-fluid -->
   </div>
   <!-- /.content-header -->

  <div class="card">
      <div class="card-header">
         <div class="col-sm-6 float-left">
            <h3 class="card-title">Post List</h3>
         </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.create', Auth::user())): ?>
         <div class="float-right">
            <a class='col-lg-offset-5 btn btn-success' href="<?php echo e(route('post.create')); ?>">Add New</a>
         </div>
         <?php endif; ?>
      </div>

            
      <!-- /.card-header -->
         <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
               <thead>
                  <tr>
                     <th>Sr. No</th>
                     <th>Post Title</th>
                     <th>Post Slug</th>
                     <th>Author</th>
                     <th>Categories</th>
                     <th>Created At</th>
                  </tr>
               </thead>

               <tbody>
                  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e($loop->index + 1); ?></td>
                     <td>
                        <div class="col-sm">
                           <?php echo e(str_limit($post->title, 50)); ?>

                        </div>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.update', Auth::user())): ?>
                        <div class="d-inline-block col-sm">
                           <div class="col-sm-6 float-left">
                              <a href="<?php echo e(route('post.edit', $post->id)); ?>">
                                 <p><i class="fa fa-pencil-square">
                                 edit</p></i>
                              </a>
                           </div>
                           <?php endif; ?>

                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('posts.delete', Auth::user())): ?>
                           <div class="col-sm-6 float-left">
                              <form id="delete-form-<?php echo e($post->id); ?>" action="<?php echo e(route('post.destroy', $post->id)); ?>" style="display: none;" method="post">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('DELETE'); ?>
                              </form>
                              <a href="<?php echo e(route('post.index')); ?>" onclick="
                              if(confirm('Are You Sure, You Want To Delete This?')){
                                 event.preventDefault();
                                 document.getElementById('delete-form-<?php echo e($post->id); ?>').submit();
                              }
                              else{
                                 event.preventDefault();
                              }">
                                 <p><i class="fa fa-trash-o">Delete</p></i>
                              </a>
                           </div>
                           <?php endif; ?>
                        </div>   
                     </td>
                     
                     <td><?php echo e($post->slug); ?></td>
                     <td><?php echo e(str_limit($user->firstname, 50)); ?> <?php echo e(str_limit($user->lastname, 50)); ?></td>
                     <td>
                        <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php echo e($category->name); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </td>
                     <td><?php echo e($post->created_at->format('jS F Y h:i:s A')); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
               <tfoot>
                  <tr>
                     <th>Sr. No</th>
                     <th>Post Title</th>
                     <th>Post Slug</th>
                     <th>Author</th>
                     <th>Categories</th>
                     <th>Created At</th>
                  </tr>
               </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>

</div>
 <?php echo $__env->make('admin/layouts/admindefaultfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  